A CDN is being planned for future releases, allowing you to reference Calcite Bootstrap static assets on a server.

For the time being - FOR DEVELOPMENT ONLY - you can pull the CSS and javascript files from github.

```
<link href="http://esri.github.io/calcite-bootstrap/assets/css/calcite-bootstrap-open.min.css" rel="stylesheet">
```