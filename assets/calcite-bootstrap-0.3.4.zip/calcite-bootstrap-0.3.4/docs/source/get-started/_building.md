Since Calcite Bootstrap is built on top of Bootstrap, the best source for documentation is the [Bootstrap](http://getbootstrap.com) site.

We have built this framework to be very familiar to the Bootstrap developer in that all of the classes and structure naming conventions are maintained throughout. This means that `btn-primary` or `col-md-7` is used the same way as you would in either framework.

There are a few custom elements that have been built in addition to the rest of the framework that help us make it ESRIfied.
