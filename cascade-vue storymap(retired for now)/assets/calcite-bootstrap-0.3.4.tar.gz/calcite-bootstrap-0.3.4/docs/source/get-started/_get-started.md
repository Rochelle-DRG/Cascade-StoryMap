There are three ways to use Calcite Bootstrap in your project:

- Copy the static files into your project
- Load files from the CDN
- Install it via NPM

We do recommend the last option and using this framework as a Sass library. This will give you the most power and flexibility. But whatever your flavor, we have you covered!